/*
 * ============================================================
 *   Solar-Powered RFID Water Vending Machine
 *   Based on: digitalmonk.biz
 *   Deployed in: Mier, Northern Cape, South Africa
 *
 *   Hardware:
 *   - ESP32-WROOM-32
 *   - RFID-RC522 Module (13.56MHz MIFARE cards)
 *   - DWIN HMI Display (UART)
 *   - Solenoid Valve (relay-controlled)
 *   - YF-S201 Flow Sensor
 *   - Solar + LiFePO4 Battery system
 *   - INA219 Battery Monitor (optional)
 *
 *   System Design:
 *   - 100% Offline – No WiFi, No GSM, No Cloud
 *   - Quota stored ON RFID card (MIFARE Classic)
 *   - 1 Litre per tap, free metered access
 *   - Sub-2 second card-to-water response
 *   - Power-loss recovery on boot
 *   - Solar/Battery monitoring + backlight dimming
 * ============================================================
 */

#include <SPI.h>
#include <MFRC522.h>       // RFID-RC522
#include <HardwareSerial.h> // DWIN Display UART
#include <EEPROM.h>        // Internal EEPROM for logs
#include <Wire.h>

// ─── Pin Definitions ───────────────────────────────────────
// RFID RC522
#define RFID_SS_PIN    5
#define RFID_RST_PIN   27

// Solenoid Valve (via relay)
#define VALVE_PIN      26   // HIGH = Open valve

// Flow Sensor (YF-S201 or similar)
#define FLOW_PIN       25   // Interrupt-capable pin

// Battery / Solar ADC
#define BATTERY_ADC    34   // ADC1 CH6 (12V divided to 3.3V)
#define SOLAR_ADC      35   // ADC1 CH7

// Status LEDs
#define LED_GREEN      32
#define LED_RED        33
#define LED_YELLOW     14

// Buzzer (passive)
#define BUZZER_PIN     12

// DWIN Display UART2
#define DWIN_RX        16
#define DWIN_TX        17

// Emergency Stop Button
#define STOP_BTN       0    // Boot button as emergency stop

// ─── RFID Sector/Block for Quota Storage ───────────────────
#define QUOTA_SECTOR     1     // MIFARE Classic Sector 1
#define QUOTA_BLOCK      4     // Block 4 (first block of sector 1)
#define QUOTA_KEY_BYTE   0x42  // Custom sector key byte
// Default key A: {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF}

// ─── Quota Configuration ───────────────────────────────────
#define LITRES_PER_TAP   1     // Litres dispensed per tap
#define MAX_QUOTA        20    // Max litres per card (weekly reset)
#define ML_PER_LITRE     1000

// ─── Flow Sensor Calibration ───────────────────────────────
// YF-S201: ~7.5 pulses/sec/litre at 1L/min
#define PULSES_PER_LITRE 450   // Calibrate for your sensor!

// ─── EEPROM Layout ─────────────────────────────────────────
#define EEPROM_SIZE         128
#define EEPROM_TOTAL_DISP   0   // 4 bytes: total litres dispensed (uint32)
#define EEPROM_TRANSACTION  4   // 4 bytes: total transactions (uint32)
#define EEPROM_LAST_UID     8   // 4 bytes: last card UID dispensed

// ─── Battery Thresholds (12V system) ───────────────────────
#define BATT_FULL_MV    13200  // 13.2V = full LiFePO4
#define BATT_LOW_MV     11800  // 11.8V = low warning
#define BATT_CUTOFF_MV  11200  // 11.2V = cutoff (protect battery)
#define ADC_REF_MV      3300
#define VOLTAGE_DIVIDER 4.0f   // R1=30k, R2=10k → divides by 4

// ─── DWIN Display Commands ─────────────────────────────────
// Page IDs for DWIN HMI
#define DWIN_PAGE_IDLE      0x00
#define DWIN_PAGE_SCAN      0x01
#define DWIN_PAGE_DISPENSING 0x02
#define DWIN_PAGE_DONE      0x03
#define DWIN_PAGE_ERROR     0x04
#define DWIN_PAGE_LOWBATT   0x05
#define DWIN_PAGE_EMPTCARD  0x06

// ─── State Machine States ──────────────────────────────────
typedef enum {
  STATE_IDLE,
  STATE_CARD_READ,
  STATE_QUOTA_CHECK,
  STATE_VALVE_OPEN,
  STATE_DISPENSING,
  STATE_VALVE_CLOSE,
  STATE_QUOTA_WRITE,
  STATE_DONE,
  STATE_ERROR,
  STATE_LOW_BATTERY,
  STATE_RECOVERY
} SystemState;

// ─── Error Codes ───────────────────────────────────────────
typedef enum {
  ERR_NONE          = 0,
  ERR_CARD_READ     = 1,
  ERR_AUTH_FAILED   = 2,
  ERR_QUOTA_EMPTY   = 3,
  ERR_VALVE_FAIL    = 4,
  ERR_FLOW_TIMEOUT  = 5,
  ERR_WRITE_FAILED  = 6,
  ERR_LOW_BATTERY   = 7
} ErrorCode;

// ─── Global Objects ────────────────────────────────────────
MFRC522 rfid(RFID_SS_PIN, RFID_RST_PIN);
MFRC522::MIFARE_Key rfidKey;
HardwareSerial dwinSerial(2); // UART2 for DWIN

// ─── Global Variables ──────────────────────────────────────
SystemState  currentState   = STATE_IDLE;
ErrorCode    lastError      = ERR_NONE;
volatile uint32_t flowPulseCount = 0;
uint32_t     targetPulses   = 0;
uint32_t     dispenseStartTime = 0;
uint32_t     totalLitres    = 0;
uint32_t     totalTrans     = 0;
int          batteryMV      = 0;
int          solarMV        = 0;
int          cardQuota      = 0;     // Remaining quota on card (litres)
byte         cardUID[4]     = {0};   // Last card UID
bool         recoveryNeeded = false;

// ─── Flow Sensor ISR ───────────────────────────────────────
void IRAM_ATTR flowPulseISR() {
  flowPulseCount++;
}

// ─── DWIN Display Communication ────────────────────────────
void dwinSendFrame(byte *data, int len) {
  // DWIN protocol: 0xAA <cmd> <data...> <checksum>
  byte checksum = 0;
  for (int i = 0; i < len; i++) checksum ^= data[i];
  dwinSerial.write(0xAA);
  dwinSerial.write(data, len);
  dwinSerial.write(checksum);
  delay(20);
}

void dwinSetPage(byte pageId) {
  byte cmd[] = {0x84, 0x00, 0x00, pageId};
  dwinSendFrame(cmd, 4);
  Serial.printf("[DWIN] Page → %d\n", pageId);
}

void dwinSetVar(uint16_t addr, uint16_t value) {
  // Write 16-bit variable to DWIN register address
  byte cmd[] = {
    0x82,
    (byte)(addr >> 8), (byte)(addr & 0xFF),
    (byte)(value >> 8), (byte)(value & 0xFF)
  };
  dwinSendFrame(cmd, 5);
}

void dwinUpdateDisplay(int quota, int battPct, bool dispensing, int mlDispensed) {
  // VP addresses (customise for your DWIN project)
  dwinSetVar(0x1000, (uint16_t)quota);        // Remaining quota
  dwinSetVar(0x1001, (uint16_t)battPct);       // Battery %
  dwinSetVar(0x1002, (uint16_t)mlDispensed);   // ML dispensed this session
  dwinSetVar(0x1003, (uint16_t)(dispensing ? 1 : 0));
}

// ─── LED & Buzzer Helpers ──────────────────────────────────
void setLED(bool green, bool red, bool yellow) {
  digitalWrite(LED_GREEN,  green  ? HIGH : LOW);
  digitalWrite(LED_RED,    red    ? HIGH : LOW);
  digitalWrite(LED_YELLOW, yellow ? HIGH : LOW);
}

void beep(int ms, int times = 1) {
  for (int i = 0; i < times; i++) {
    digitalWrite(BUZZER_PIN, HIGH);
    delay(ms);
    digitalWrite(BUZZER_PIN, LOW);
    if (times > 1) delay(80);
  }
}

void beepSuccess() { beep(100, 2); }
void beepError()   { beep(400, 1); }
void beepWarning() { beep(200, 3); }

// ─── Battery Monitoring ────────────────────────────────────
int readVoltage(int pin) {
  // Average 10 samples
  long sum = 0;
  for (int i = 0; i < 10; i++) {
    sum += analogRead(pin);
    delay(2);
  }
  int raw = sum / 10;
  // ESP32 ADC: 12-bit, 0-4095 = 0-3300mV
  int adcMV = (raw * ADC_REF_MV) / 4095;
  return (int)(adcMV * VOLTAGE_DIVIDER);
}

int batteryPercent(int mv) {
  // LiFePO4 13.2V = 100%, 11.2V = 0%
  int pct = map(mv, BATT_CUTOFF_MV, BATT_FULL_MV, 0, 100);
  return constrain(pct, 0, 100);
}

// ─── RFID Helpers ──────────────────────────────────────────
bool rfidAuthenticate(byte block) {
  MFRC522::StatusCode status = rfid.PCD_Authenticate(
    MFRC522::PICC_CMD_MF_AUTH_KEY_A,
    block, &rfidKey, &(rfid.uid)
  );
  return (status == MFRC522::STATUS_OK);
}

bool readCardQuota(int &quota) {
  byte block = QUOTA_BLOCK;
  byte buffer[18];
  byte size = sizeof(buffer);

  if (!rfidAuthenticate(block)) {
    Serial.println("[RFID] Auth failed");
    lastError = ERR_AUTH_FAILED;
    return false;
  }

  MFRC522::StatusCode status = rfid.MIFARE_Read(block, buffer, &size);
  if (status != MFRC522::STATUS_OK) {
    Serial.println("[RFID] Read failed");
    lastError = ERR_CARD_READ;
    return false;
  }

  // Quota stored in bytes 0-1 (big-endian uint16)
  // Byte 2-3: checksum (XOR)
  uint16_t rawQuota = ((uint16_t)buffer[0] << 8) | buffer[1];
  byte chk = buffer[0] ^ buffer[1] ^ QUOTA_KEY_BYTE;
  if (chk != buffer[2]) {
    Serial.println("[RFID] Checksum mismatch – treating as new card");
    rawQuota = MAX_QUOTA; // New/unformatted card gets full quota
  }

  quota = rawQuota;
  Serial.printf("[RFID] Card quota: %d L\n", quota);
  return true;
}

bool writeCardQuota(int quota) {
  byte block = QUOTA_BLOCK;

  if (!rfidAuthenticate(block)) {
    lastError = ERR_WRITE_FAILED;
    return false;
  }

  byte buffer[16] = {0};
  buffer[0] = (byte)(quota >> 8);
  buffer[1] = (byte)(quota & 0xFF);
  buffer[2] = buffer[0] ^ buffer[1] ^ QUOTA_KEY_BYTE; // checksum

  MFRC522::StatusCode status = rfid.MIFARE_Write(block, buffer, 16);
  if (status != MFRC522::STATUS_OK) {
    Serial.println("[RFID] Write failed!");
    lastError = ERR_WRITE_FAILED;
    return false;
  }

  Serial.printf("[RFID] Written quota: %d L\n", quota);
  return true;
}

void captureUID() {
  for (int i = 0; i < 4 && i < (int)rfid.uid.size; i++) {
    cardUID[i] = rfid.uid.uidByte[i];
  }
}

void printUID() {
  Serial.print("[RFID] UID: ");
  for (int i = 0; i < 4; i++) {
    if (cardUID[i] < 0x10) Serial.print("0");
    Serial.print(cardUID[i], HEX);
    if (i < 3) Serial.print(":");
  }
  Serial.println();
}

// ─── Valve Control ─────────────────────────────────────────
void openValve() {
  digitalWrite(VALVE_PIN, HIGH);
  Serial.println("[VALVE] OPENED");
}

void closeValve() {
  digitalWrite(VALVE_PIN, LOW);
  Serial.println("[VALVE] CLOSED");
}

// ─── EEPROM Log ────────────────────────────────────────────
void loadEEPROM() {
  EEPROM.begin(EEPROM_SIZE);
  EEPROM.get(EEPROM_TOTAL_DISP, totalLitres);
  EEPROM.get(EEPROM_TRANSACTION, totalTrans);
  if (totalLitres == 0xFFFFFFFF) totalLitres = 0;
  if (totalTrans  == 0xFFFFFFFF) totalTrans  = 0;
  Serial.printf("[EEPROM] Total dispensed: %u L | Transactions: %u\n",
                totalLitres, totalTrans);
}

void saveEEPROM() {
  EEPROM.put(EEPROM_TOTAL_DISP, totalLitres);
  EEPROM.put(EEPROM_TRANSACTION, totalTrans);
  EEPROM.put(EEPROM_LAST_UID, *(uint32_t*)cardUID);
  EEPROM.commit();
}

// ─── State Machine Transitions ─────────────────────────────
void transitionTo(SystemState newState) {
  Serial.printf("[STATE] %d → %d\n", currentState, newState);
  currentState = newState;
}

// ─── Error Handler ─────────────────────────────────────────
void handleError(ErrorCode err) {
  lastError = err;
  closeValve();
  setLED(false, true, false);
  beepError();
  dwinSetPage(DWIN_PAGE_ERROR);
  dwinSetVar(0x2000, (uint16_t)err); // Send error code to display
  Serial.printf("[ERROR] Code: %d\n", err);
  transitionTo(STATE_ERROR);
}

// ─── State: IDLE ───────────────────────────────────────────
void stateIdle() {
  static unsigned long lastBlink = 0;
  static bool ledState = false;

  // Blink green LED slowly
  if (millis() - lastBlink > 800) {
    ledState = !ledState;
    setLED(ledState, false, false);
    lastBlink = millis();
  }

  dwinSetPage(DWIN_PAGE_IDLE);

  // Battery check
  batteryMV = readVoltage(BATTERY_ADC);
  solarMV   = readVoltage(SOLAR_ADC);

  if (batteryMV < BATT_CUTOFF_MV) {
    transitionTo(STATE_LOW_BATTERY);
    return;
  }

  // Dim display if battery low
  if (batteryMV < BATT_LOW_MV) {
    dwinSetVar(0x0082, 60); // 60% brightness
    setLED(false, false, true); // Yellow warning
  } else {
    dwinSetVar(0x0082, 100); // Full brightness
  }

  dwinUpdateDisplay(0, batteryPercent(batteryMV), false, 0);

  // Wait for card
  if (rfid.PICC_IsNewCardPresent() && rfid.PICC_ReadCardSerial()) {
    captureUID();
    printUID();
    beep(50);
    dwinSetPage(DWIN_PAGE_SCAN);
    transitionTo(STATE_CARD_READ);
  }
}

// ─── State: CARD_READ ──────────────────────────────────────
void stateCardRead() {
  setLED(true, false, true); // Green + Yellow = reading

  if (!readCardQuota(cardQuota)) {
    handleError(lastError);
    rfid.PICC_HaltA();
    rfid.PCD_StopCrypto1();
    return;
  }

  transitionTo(STATE_QUOTA_CHECK);
}

// ─── State: QUOTA_CHECK ────────────────────────────────────
void stateQuotaCheck() {
  if (cardQuota < LITRES_PER_TAP) {
    // Empty card
    Serial.println("[QUOTA] Card empty!");
    beepWarning();
    dwinSetPage(DWIN_PAGE_EMPTCARD);
    dwinSetVar(0x1000, 0);
    setLED(false, true, false);
    rfid.PICC_HaltA();
    rfid.PCD_StopCrypto1();
    delay(3000);
    transitionTo(STATE_IDLE);
    return;
  }

  Serial.printf("[QUOTA] OK — %d L remaining\n", cardQuota);
  dwinUpdateDisplay(cardQuota, batteryPercent(batteryMV), false, 0);
  transitionTo(STATE_VALVE_OPEN);
}

// ─── State: VALVE_OPEN ─────────────────────────────────────
void stateValveOpen() {
  // Reset flow counter
  noInterrupts();
  flowPulseCount = 0;
  interrupts();

  targetPulses      = LITRES_PER_TAP * PULSES_PER_LITRE;
  dispenseStartTime = millis();

  openValve();
  setLED(true, false, false); // Solid green = dispensing
  dwinSetPage(DWIN_PAGE_DISPENSING);
  transitionTo(STATE_DISPENSING);

  Serial.printf("[VALVE] Open — Target: %u pulses (%d L)\n",
                targetPulses, LITRES_PER_TAP);
}

// ─── State: DISPENSING ─────────────────────────────────────
void stateDispensing() {
  uint32_t pulses;
  noInterrupts();
  pulses = flowPulseCount;
  interrupts();

  // Update display with ML dispensed
  int mlDispensed = (int)((pulses * ML_PER_LITRE) / PULSES_PER_LITRE);
  dwinUpdateDisplay(cardQuota, batteryPercent(batteryMV), true, mlDispensed);

  // Emergency stop
  if (digitalRead(STOP_BTN) == LOW) {
    Serial.println("[STOP] Emergency stop!");
    closeValve();
    transitionTo(STATE_VALVE_CLOSE);
    return;
  }

  // Check if target reached
  if (pulses >= targetPulses) {
    Serial.printf("[FLOW] Target reached: %u pulses\n", pulses);
    transitionTo(STATE_VALVE_CLOSE);
    return;
  }

  // Timeout protection (max 30 seconds for 1L)
  if (millis() - dispenseStartTime > 30000) {
    Serial.println("[FLOW] Timeout!");
    closeValve();
    handleError(ERR_FLOW_TIMEOUT);
    return;
  }
}

// ─── State: VALVE_CLOSE ────────────────────────────────────
void stateValveClose() {
  closeValve();
  delay(200); // Allow valve to settle

  uint32_t pulses;
  noInterrupts();
  pulses = flowPulseCount;
  interrupts();

  int actualML = (int)((pulses * ML_PER_LITRE) / PULSES_PER_LITRE);
  int actualL  = (actualML >= 800) ? LITRES_PER_TAP : 0; // 800ml minimum

  Serial.printf("[DISPENSE] Actual: %d ml (%d L)\n", actualML, actualL);
  transitionTo(STATE_QUOTA_WRITE);
}

// ─── State: QUOTA_WRITE ────────────────────────────────────
void stateQuotaWrite() {
  int newQuota = cardQuota - LITRES_PER_TAP;
  if (newQuota < 0) newQuota = 0;

  if (!writeCardQuota(newQuota)) {
    // Critical: quota not written, but water dispensed
    // Log to EEPROM and show error
    Serial.println("[CRITICAL] Quota write failed! Logging...");
    handleError(ERR_WRITE_FAILED);
    rfid.PICC_HaltA();
    rfid.PCD_StopCrypto1();
    return;
  }

  cardQuota = newQuota;

  // Update logs
  totalLitres += LITRES_PER_TAP;
  totalTrans++;
  saveEEPROM();

  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();

  transitionTo(STATE_DONE);
}

// ─── State: DONE ───────────────────────────────────────────
void stateDone() {
  beepSuccess();
  setLED(true, false, false);
  dwinSetPage(DWIN_PAGE_DONE);
  dwinUpdateDisplay(cardQuota, batteryPercent(batteryMV), false, ML_PER_LITRE);

  Serial.printf("[DONE] Card quota now: %d L | Total dispensed: %u L\n",
                cardQuota, totalLitres);

  delay(3000); // Show completion screen for 3 seconds
  transitionTo(STATE_IDLE);
}

// ─── State: ERROR ──────────────────────────────────────────
void stateError() {
  // Stay on error screen for 4 seconds, then back to idle
  static unsigned long errorTime = 0;
  if (errorTime == 0) errorTime = millis();

  if (millis() - errorTime > 4000) {
    errorTime = 0;
    lastError = ERR_NONE;
    rfid.PICC_HaltA();
    rfid.PCD_StopCrypto1();
    transitionTo(STATE_IDLE);
  }
}

// ─── State: LOW_BATTERY ────────────────────────────────────
void stateLowBattery() {
  closeValve();
  setLED(false, true, true); // Red + Yellow
  beepWarning();
  dwinSetPage(DWIN_PAGE_LOWBATT);
  dwinSetVar(0x1001, batteryPercent(batteryMV));

  Serial.printf("[BATTERY] CRITICAL: %d mV (%d%%)\n",
                batteryMV, batteryPercent(batteryMV));

  // Re-check every 30 seconds
  delay(30000);
  batteryMV = readVoltage(BATTERY_ADC);

  if (batteryMV > BATT_LOW_MV) {
    Serial.println("[BATTERY] Recovered");
    transitionTo(STATE_IDLE);
  }
}

// ─── State: RECOVERY (Power-Loss Recovery) ─────────────────
void stateRecovery() {
  Serial.println("[RECOVERY] Checking last transaction...");
  closeValve(); // Always close valve on boot recovery

  // Load state from EEPROM
  loadEEPROM();

  // A short delay to allow DWIN display to boot
  delay(1500);
  dwinSetPage(DWIN_PAGE_IDLE);

  Serial.println("[RECOVERY] System ready");
  transitionTo(STATE_IDLE);
}

// ─── SETUP ─────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  Serial.println("\n========================================");
  Serial.println("  Solar RFID Water Vending Machine");
  Serial.println("  ESP32 Firmware v1.0");
  Serial.println("  DigitalMonk Engineering");
  Serial.println("========================================\n");

  // GPIO init
  pinMode(VALVE_PIN,   OUTPUT);
  pinMode(LED_GREEN,   OUTPUT);
  pinMode(LED_RED,     OUTPUT);
  pinMode(LED_YELLOW,  OUTPUT);
  pinMode(BUZZER_PIN,  OUTPUT);
  pinMode(STOP_BTN,    INPUT_PULLUP);
  pinMode(FLOW_PIN,    INPUT_PULLUP);

  // Safety: close valve on boot
  closeValve();
  setLED(false, false, false);
  digitalWrite(BUZZER_PIN, LOW);

  // Flow sensor interrupt
  attachInterrupt(digitalPinToInterrupt(FLOW_PIN), flowPulseISR, FALLING);

  // DWIN Display (UART2: RX=16, TX=17)
  dwinSerial.begin(115200, SERIAL_8N1, DWIN_RX, DWIN_TX);
  delay(500);

  // SPI + RFID
  SPI.begin();
  rfid.PCD_Init();
  rfid.PCD_SetAntennaGain(rfid.RxGain_max);

  // Set RFID key (default: 0xFF x6)
  for (byte i = 0; i < 6; i++) rfidKey.keyByte[i] = 0xFF;

  // EEPROM
  loadEEPROM();

  // Battery check at boot
  batteryMV = readVoltage(BATTERY_ADC);
  solarMV   = readVoltage(SOLAR_ADC);
  Serial.printf("[BOOT] Battery: %d mV (%d%%) | Solar: %d mV\n",
                batteryMV, batteryPercent(batteryMV), solarMV);

  // Startup beep & LED flash
  setLED(true, true, true);
  beep(100, 3);
  delay(300);
  setLED(false, false, false);

  // Boot to recovery state first
  transitionTo(STATE_RECOVERY);
  Serial.println("[BOOT] System initialized. Entering recovery check...");
}

// ─── LOOP ──────────────────────────────────────────────────
void loop() {
  switch (currentState) {

    case STATE_IDLE:
      stateIdle();
      break;

    case STATE_CARD_READ:
      stateCardRead();
      break;

    case STATE_QUOTA_CHECK:
      stateQuotaCheck();
      break;

    case STATE_VALVE_OPEN:
      stateValveOpen();
      break;

    case STATE_DISPENSING:
      stateDispensing();
      break;

    case STATE_VALVE_CLOSE:
      stateValveClose();
      break;

    case STATE_QUOTA_WRITE:
      stateQuotaWrite();
      break;

    case STATE_DONE:
      stateDone();
      break;

    case STATE_ERROR:
      stateError();
      break;

    case STATE_LOW_BATTERY:
      stateLowBattery();
      break;

    case STATE_RECOVERY:
      stateRecovery();
      break;

    default:
      transitionTo(STATE_IDLE);
      break;
  }

  // Brief yield for watchdog
  delay(10);
}
