# ☀️ Solar-Powered RFID Water Vending Machine
### ESP32 Firmware — Offline, Off-Grid, Quota-Based Water Dispensing

> Based on the DigitalMonk project deployed in **Mier, Northern Cape, South Africa**  
> 100% offline · Solar powered · RFID quota cards · No internet required

---

## 📁 Project Structure

```
Solar_RFID_Water_Vending/
│
├── Solar_RFID_Water_Vending.ino   ← MAIN FIRMWARE (upload this)
│
├── Card_Admin_Tool/
│   └── Card_Admin_Tool.ino        ← Format/read/reset RFID cards
│
├── Flow_Calibration/
│   └── Flow_Calibration.ino       ← Calibrate your flow sensor
│
└── README.md                      ← This file
```

---

## 🧠 How It Works

```
CARD TAP
   ↓
READ RFID CARD → Check quota on card
   ↓
QUOTA OK? → Open solenoid valve
   ↓
FLOW SENSOR counts pulses → 1 litre dispensed
   ↓
CLOSE VALVE → Write new quota back to card
   ↓
DONE — Card updated, log saved to EEPROM
```

**Key design principle:** The card IS the database. No server. No cloud. No single point of failure.

---

## 🔌 Wiring Diagram

### ESP32 Pin Map

| Component | Pin | ESP32 GPIO |
|-----------|-----|-----------|
| RFID RC522 SS | CS | GPIO 5 |
| RFID RC522 RST | RST | GPIO 27 |
| RFID RC522 MOSI | MOSI | GPIO 23 |
| RFID RC522 MISO | MISO | GPIO 19 |
| RFID RC522 SCK | CLK | GPIO 18 |
| Solenoid Valve (relay) | IN | GPIO 26 |
| Flow Sensor (YF-S201) | DATA | GPIO 25 |
| DWIN Display RX | TX | GPIO 17 |
| DWIN Display TX | RX | GPIO 16 |
| Battery ADC | ADC | GPIO 34 |
| Solar ADC | ADC | GPIO 35 |
| LED Green | — | GPIO 32 |
| LED Red | — | GPIO 33 |
| LED Yellow | — | GPIO 14 |
| Buzzer | — | GPIO 12 |
| Emergency Stop | Boot button | GPIO 0 |

### Battery Voltage Divider (12V → 3.3V)
```
12V Battery (+) ──┬── 30kΩ ──┬── GPIO 34
                             │
                          10kΩ
                             │
                            GND
```
This divides 12V by 4 → safe for ESP32 ADC (max 3.3V)

### Solenoid Valve Relay Wiring
```
ESP32 GPIO 26 → Relay IN
Relay COM → 12V Battery (+)
Relay NO  → Solenoid Valve (+)
Solenoid Valve (−) → GND
```
> ⚠️ Use a flyback diode across the solenoid to protect the relay.

---

## 📚 Required Libraries

Install via **Arduino IDE → Tools → Manage Libraries**:

| Library | Install Name |
|---------|-------------|
| **MFRC522** | `MFRC522` by GithubCommunity |
| ESP32 Core | (from Board Manager) |

No other external libraries needed — uses built-in SPI, HardwareSerial, EEPROM, Wire.

---

## ⚙️ Arduino IDE Setup

### Step 1: Install ESP32 Board
1. File → Preferences → Additional Board Manager URLs:
   ```
   https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json
   ```
2. Tools → Board Manager → Search "esp32" → Install **"esp32 by Espressif Systems"**

### Step 2: Install MFRC522 Library
Tools → Manage Libraries → Search "MFRC522" → Install

### Step 3: Board Settings
```
Board:           ESP32 Dev Module
Upload Speed:    921600
CPU Frequency:   240MHz
Flash Mode:      QIO
Flash Size:      4MB
Partition Scheme: Default
Core Debug Level: None
```

### Step 4: Upload
Connect ESP32 via USB → Select Port → Click Upload ▶️

---

## 🔧 Configuration (edit in main .ino)

```cpp
// WiFi (not used — system is offline)
// No WiFi config needed!

// Quota Settings
#define LITRES_PER_TAP   1     // Litres per card tap
#define MAX_QUOTA        20    // Weekly allocation per card

// Flow Sensor (CALIBRATE FIRST!)
#define PULSES_PER_LITRE 450   // Run Flow_Calibration sketch to find this

// Battery Thresholds (12V LiFePO4 system)
#define BATT_FULL_MV    13200
#define BATT_LOW_MV     11800
#define BATT_CUTOFF_MV  11200

// Voltage Divider Ratio
#define VOLTAGE_DIVIDER 4.0f   // Matches R1=30k, R2=10k
```

---

## 🪪 RFID Card Setup

### New Cards (must format before use)
1. Upload `Card_Admin_Tool.ino`
2. Set `#define ADMIN_MODE 2` (write MAX_QUOTA)
3. Tap new MIFARE Classic 1K card
4. Card is now ready for the vending machine

### Read a Card's Quota
1. Set `#define ADMIN_MODE 1`
2. Tap card → quota shown in Serial Monitor

### Reset Card to Full Quota
1. Set `#define ADMIN_MODE 2`
2. Tap card → reset to 20L (MAX_QUOTA)

### Write Custom Quota
1. Set `#define ADMIN_MODE 3`
2. Set `#define CUSTOM_QUOTA 10` (your value)
3. Tap card → written

---

## 🔬 Flow Sensor Calibration

**Do this before deploying!** Sensor pulse rate varies by model and water pressure.

1. Upload `Flow_Calibration.ino`
2. Connect flow sensor to GPIO 25
3. Open Serial Monitor (115200 baud)
4. Press BOOT button → start collection
5. Collect **exactly 1 litre** of water
6. Press BOOT button → stop
7. Note the `PULSES_PER_LITRE` value
8. Update `#define PULSES_PER_LITRE` in main sketch

---

## 🖥️ DWIN HMI Display Setup

The DWIN display uses UART at 115200 baud (GPIO 16/17).

### DGUS Variable Addresses Used:
| Address | Data | Description |
|---------|------|-------------|
| 0x1000 | uint16 | Card remaining quota (litres) |
| 0x1001 | uint16 | Battery percentage (0-100) |
| 0x1002 | uint16 | ML dispensed this session |
| 0x1003 | uint16 | 1=dispensing, 0=idle |
| 0x2000 | uint16 | Error code |
| 0x0082 | uint16 | Display brightness (0-100) |

### Page IDs:
| Page | Screen |
|------|--------|
| 0x00 | Idle — waiting for card |
| 0x01 | Scanning card |
| 0x02 | Dispensing water |
| 0x03 | Done — transaction complete |
| 0x04 | Error screen |
| 0x05 | Low battery warning |
| 0x06 | Empty card (quota = 0) |

> Design your DWIN pages in DGUS II IDE and flash to display SD card.  
> If you don't have a DWIN display, comment out `dwinSerial.begin()` — the machine works without it.

---

## ☀️ Power System

```
Solar Panel (12V, 20-50W recommended)
      ↓
Solar Charge Controller (PWM or MPPT)
      ↓
LiFePO4 Battery Bank (12V, 30-100Ah)
      ↓
Buck Converter (12V → 5V, 3A) → ESP32 VIN
Buck Converter (12V → 5V, 3A) → DWIN Display
12V direct → Solenoid Valve relay
```

### Battery Autonomy
| Battery | Autonomy (no sun) |
|---------|------------------|
| 30Ah LiFePO4 | ~3 days |
| 50Ah LiFePO4 | ~5 days |
| 100Ah LiFePO4 | ~10 days |

---

## 🛠️ Troubleshooting

| Problem | Solution |
|---------|----------|
| Card not reading | Check RFID wiring, increase antenna gain in code |
| Wrong quota on card | Run Card_Admin_Tool to reset |
| Valve not opening | Check relay wiring, verify GPIO 26 goes HIGH |
| Flow not counting | Check YF-S201 wiring, run Flow_Calibration |
| Battery% always 0 | Verify voltage divider resistors and ADC pin |
| DWIN screen blank | Check UART wiring GPIO 16/17, verify baud rate |
| System stuck in ERROR | Check Serial Monitor for error code details |

---

## 📊 State Machine

```
RECOVERY → IDLE → CARD_READ → QUOTA_CHECK → VALVE_OPEN
                                                  ↓
                              DONE ← QUOTA_WRITE ← VALVE_CLOSE ← DISPENSING
                               ↓
                             IDLE
                    
ERROR (any state) → ERROR → IDLE (after 4s)
LOW_BATTERY → monitor → IDLE (when recovered)
```

---

## 📝 EEPROM Data Layout

| Address | Size | Data |
|---------|------|------|
| 0x00 | 4 bytes | Total litres dispensed (uint32) |
| 0x04 | 4 bytes | Total transactions (uint32) |
| 0x08 | 4 bytes | Last card UID (uint32) |

---

*Built with ❤️ for communities that need it most.*
