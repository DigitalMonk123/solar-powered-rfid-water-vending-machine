/*
 * ============================================================
 *   RFID Card Admin Tool
 *   Solar RFID Water Vending Machine
 *   
 *   Use this sketch to:
 *   - Format new MIFARE cards with quota
 *   - Read existing card quota
 *   - Reset card to full quota (MAX_QUOTA)
 *   - Wipe/blank a card
 *
 *   Upload this separately for card management tasks.
 *   Use main sketch for the vending machine itself.
 * ============================================================
 */

#include <SPI.h>
#include <MFRC522.h>

#define RFID_SS_PIN   5
#define RFID_RST_PIN  27
#define QUOTA_BLOCK   4
#define MAX_QUOTA     20
#define QUOTA_KEY_BYTE 0x42

MFRC522 rfid(RFID_SS_PIN, RFID_RST_PIN);
MFRC522::MIFARE_Key rfidKey;

// ─── Admin Mode ────────────────────────────────────────────
// 1 = Read quota
// 2 = Write/Reset to MAX_QUOTA
// 3 = Write custom quota (set CUSTOM_QUOTA below)
// 4 = Dump card blocks
#define ADMIN_MODE     2
#define CUSTOM_QUOTA   10  // Used only when ADMIN_MODE = 3

bool authenticate(byte block) {
  return rfid.PCD_Authenticate(
    MFRC522::PICC_CMD_MF_AUTH_KEY_A,
    block, &rfidKey, &rfid.uid
  ) == MFRC522::STATUS_OK;
}

void readQuota() {
  byte buffer[18];
  byte size = sizeof(buffer);

  if (!authenticate(QUOTA_BLOCK)) {
    Serial.println("Auth failed!");
    return;
  }

  if (rfid.MIFARE_Read(QUOTA_BLOCK, buffer, &size) != MFRC522::STATUS_OK) {
    Serial.println("Read failed!");
    return;
  }

  uint16_t quota = ((uint16_t)buffer[0] << 8) | buffer[1];
  byte chk = buffer[0] ^ buffer[1] ^ QUOTA_KEY_BYTE;

  Serial.print("Quota: ");
  Serial.print(quota);
  Serial.println(" L");
  Serial.print("Checksum: ");
  Serial.println(chk == buffer[2] ? "VALID" : "INVALID (new/corrupt card)");
}

void writeQuota(int quota) {
  byte buffer[16] = {0};
  buffer[0] = (byte)(quota >> 8);
  buffer[1] = (byte)(quota & 0xFF);
  buffer[2] = buffer[0] ^ buffer[1] ^ QUOTA_KEY_BYTE;

  if (!authenticate(QUOTA_BLOCK)) {
    Serial.println("Auth failed!");
    return;
  }

  if (rfid.MIFARE_Write(QUOTA_BLOCK, buffer, 16) == MFRC522::STATUS_OK) {
    Serial.printf("Written quota: %d L — SUCCESS\n", quota);
  } else {
    Serial.println("Write FAILED!");
  }
}

void dumpCard() {
  for (byte block = 0; block < 16; block++) {
    // Authenticate each sector (blocks 0-3 = sector 0, etc.)
    byte sector = block / 4;
    byte sectorBlock = sector * 4 + 3; // Sector trailer

    rfid.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A,
                          sectorBlock, &rfidKey, &rfid.uid);

    byte buffer[18];
    byte size = sizeof(buffer);
    if (rfid.MIFARE_Read(block, buffer, &size) == MFRC522::STATUS_OK) {
      Serial.printf("Block %02d: ", block);
      for (int i = 0; i < 16; i++) {
        if (buffer[i] < 0x10) Serial.print("0");
        Serial.print(buffer[i], HEX);
        Serial.print(" ");
      }
      Serial.println();
    }
  }
}

void setup() {
  Serial.begin(115200);
  SPI.begin();
  rfid.PCD_Init();

  for (byte i = 0; i < 6; i++) rfidKey.keyByte[i] = 0xFF;

  Serial.println("=== RFID Card Admin Tool ===");
  Serial.printf("Mode: %d | Max Quota: %d L\n", ADMIN_MODE, MAX_QUOTA);
  Serial.println("Waiting for card...");
}

void loop() {
  if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial()) {
    delay(100);
    return;
  }

  Serial.print("Card UID: ");
  for (byte i = 0; i < rfid.uid.size; i++) {
    if (rfid.uid.uidByte[i] < 0x10) Serial.print("0");
    Serial.print(rfid.uid.uidByte[i], HEX);
    Serial.print(" ");
  }
  Serial.println();

  switch (ADMIN_MODE) {
    case 1:
      readQuota();
      break;
    case 2:
      writeQuota(MAX_QUOTA);
      break;
    case 3:
      writeQuota(CUSTOM_QUOTA);
      break;
    case 4:
      dumpCard();
      break;
    default:
      Serial.println("Invalid mode!");
  }

  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();
  delay(2000); // Wait before reading next card
}
