/*
 * ============================================================
 *   Flow Sensor Calibration Tool
 *   Solar RFID Water Vending Machine
 *
 *   Run this sketch to find the correct PULSES_PER_LITRE
 *   value for your specific flow sensor and water pressure.
 *
 *   Instructions:
 *   1. Upload this sketch
 *   2. Open Serial Monitor at 115200 baud
 *   3. Press BOOT button to start 1-litre measurement
 *   4. Collect EXACTLY 1 litre in a measuring container
 *   5. Press BOOT button again to stop
 *   6. Note the PULSES_PER_LITRE value shown
 *   7. Copy this value into the main sketch
 * ============================================================
 */

#include <Arduino.h>

#define FLOW_PIN    25
#define BUTTON_PIN   0   // Boot button

volatile uint32_t pulseCount = 0;
bool measuring = false;
unsigned long startTime = 0;

void IRAM_ATTR flowISR() {
  pulseCount++;
}

void setup() {
  Serial.begin(115200);
  pinMode(FLOW_PIN, INPUT_PULLUP);
  pinMode(BUTTON_PIN, INPUT_PULLUP);

  attachInterrupt(digitalPinToInterrupt(FLOW_PIN), flowISR, FALLING);

  Serial.println("=== Flow Sensor Calibration ===");
  Serial.println("Press BOOT button to START measurement.");
  Serial.println("Collect exactly 1 litre, then press BOOT again.");
}

void loop() {
  static bool lastBtn = HIGH;
  bool btn = digitalRead(BUTTON_PIN);

  if (lastBtn == HIGH && btn == LOW) {
    delay(50); // debounce
    if (!measuring) {
      // Start measurement
      noInterrupts();
      pulseCount = 0;
      interrupts();
      startTime  = millis();
      measuring  = true;
      Serial.println("\n▶ Measuring started. Collect 1 litre now...");
    } else {
      // Stop measurement
      measuring = false;
      unsigned long elapsed = millis() - startTime;

      noInterrupts();
      uint32_t p = pulseCount;
      interrupts();

      float flowRate = (float)p / (elapsed / 1000.0f);

      Serial.println("\n⏹ Measurement stopped.");
      Serial.printf("   Pulses counted   : %u\n", p);
      Serial.printf("   Time elapsed     : %.2f seconds\n", elapsed / 1000.0f);
      Serial.printf("   Flow rate        : %.1f pulses/sec\n", flowRate);
      Serial.println();
      Serial.println("╔══════════════════════════════╗");
      Serial.printf("║  PULSES_PER_LITRE = %u       ║\n", p);
      Serial.println("╚══════════════════════════════╝");
      Serial.println("\nCopy this value into Solar_RFID_Water_Vending.ino");
      Serial.println("Press BOOT to measure again.");
    }
  }

  // Live pulse display while measuring
  if (measuring) {
    static unsigned long lastPrint = 0;
    if (millis() - lastPrint > 500) {
      noInterrupts();
      uint32_t p = pulseCount;
      interrupts();
      Serial.printf("Pulses: %u | Time: %.1f s\r",
                    p, (millis() - startTime) / 1000.0f);
      lastPrint = millis();
    }
  }

  lastBtn = btn;
  delay(10);
}
